import React from 'react'
import CartClient from './CartClient'

const Cart = () => {
  return (
    <div className='p-5'>
      <CartClient />
    </div>
  )
}

export default Cart;
