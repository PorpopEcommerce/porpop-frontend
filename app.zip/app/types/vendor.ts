
export type VendorData = {
  city: string;
  shop_name: string;
  shop_url: string;
  shop_description: string;
  street: string;
  country: string;
 
}
