'use client';

import UserDashboard from './userDashboard/UserDashboard';


const AccountPage = () => {


  return (
    <div>
      <UserDashboard />
    </div>
  );
};

export default AccountPage;
