import React from 'react'

const CVListing = () => {
  return (
    <div>
      You haven't created any CVs yet.
    </div>
  )
}

export default CVListing
